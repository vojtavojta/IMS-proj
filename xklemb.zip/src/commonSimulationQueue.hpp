//
//  commonSimulationQueue.hpp
//  SimSimLib
//
//  Created by Radovan Klembara on 05/12/2020.
//

#ifndef commonSimulationQueue_hpp
#define commonSimulationQueue_hpp

#include "priorityQueue.hpp"

extern EventPriorityQueue* eventQueue;

#endif /* commonSimulationQueue_hpp */
