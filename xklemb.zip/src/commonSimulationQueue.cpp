//
//  commonSimulationQueue.cpp
//  SimSimLib
//
//  Created by Radovan Klembara on 05/12/2020.
//

#include "commonSimulationQueue.hpp"

EventPriorityQueue* eventQueue = new EventPriorityQueue();
