//
//  currentSimTime.hpp
//  SimSimLib
//
//  Created by Radovan Klembara on 29/11/2020.
//

#ifndef currentSimTime_hpp
#define currentSimTime_hpp

// Current time of simulation
extern const double & current_time;

#endif /* currentSimTime_hpp */
